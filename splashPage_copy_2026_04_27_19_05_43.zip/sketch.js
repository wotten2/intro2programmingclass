var mode = 0;
var chicken
var cluck
let startTime = 0;
let rate = 1;
let duration;
let playing = false;
var fft
var midX 
var midY 

function preload() {
  chicken = loadImage('pngegg.png');
  cluck = loadSound('chickennoise.mp3')
}

function mousePressed() {
  playing = true;
}


function setup() {
  createCanvas(windowWidth, windowHeight)
  splash = new Splash();
  
    midX = width/2
  midY = height/2
  duration = cluck.duration()
}

function draw() {
  if (mouseIsPressed == true && splash.update() == true) {
    mode = 1;
  }
  
  if (mode == 1) {
    splash.hide();
    
    background(255, 230, 0);

  speech()
  
  
 image(chicken, 0, 0, width, height, 0, 0, chicken.width, chicken.height, CONTAIN);

   startTime = constrain(map(mouseX, 0, width, 0, duration), 0, duration-2);
  if (playing==true) {
    fft = new p5.FFT();
    cluck.play()
    cluck.amp(0.4)
    cluck.jump(startTime, 3);
    startTime = random(0, duration);
    rate = 1
    cluck.loop()
  }
  }
}


function speech(){
  
  fill(255)
  // triangle()
  ellipse(width/7, height/5, midX/2, midY/2 )
  
  
}

function landing(){
  
  text ('Are you ready to recieve your life changing fortune from the world famous psychic chicken?', 10, 10)
  
  
}


function question1(){
  
  let myRadio = createRadio();
  myRadio.position(0, 0);
  myRadio.size(50);
  myRadio.option('Advice');
  myRadio.option('Inspiration');
  myRadio.option('Love');
  myRadio.option('Career');

  }



